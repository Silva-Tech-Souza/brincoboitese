<div class="sidebar" id="sidebar">
                <div class="sidebar-inner slimscroll">
					<div class="sidebar-menu">
						<ul>
							<li> 
								<a href="index.php"><i class="la la-home"></i> <span>Voltar para Home</span></a>
							</li>
							<li class="menu-title">Configurações</li>
							
				
							<li> 
								<a href="theme-settings.php"><i class="la la-photo"></i> <span>Configurações de Tema</span></a>
							</li>
							<li> 
								<a href="roles-permissions.php"><i class="la la-key"></i> <span>Funções e Permissões</span></a>
							</li>
							
						
							
							<li> 
								<a href="salary-settings.php"><i class="la la-money"></i> <span>Configurações de Fatura</span></a>
							</li>
							
							<li> 
								<a href="change-password.php"><i class="la la-lock"></i> <span>Mudar senha</span></a>
							</li>
							
						</ul>
					</div>
                </div>
            </div>